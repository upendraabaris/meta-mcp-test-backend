import { McpClient } from "@modelcontextprotocol/sdk/client/mcp.js";

export async function createMcpClient() {
  try {
    // Adjust the transport path to your actual MCP server setup
    const client = await McpClient.connect({
      name: "meta-ads-client",
      version: "1.0.0",
      transport: {
        type: "stdio", // change to "websocket" or "unix" if needed
        path: "/tmp/mcp-server.sock", // replace with your actual socket/transport
      },
    });

    console.log("🔗 Connected to MCP server successfully");
    return client;
  } catch (err) {
    console.error("❌ Error connecting to MCP server:", err);
    throw err;
  }
}
