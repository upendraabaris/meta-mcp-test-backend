import express from "express";
import bodyParser from "body-parser";
import { createMcpClient } from "./createMcpClient.js";

const app = express();
app.use(bodyParser.json());

let mcpClient;

(async () => {
  try {
    mcpClient = await createMcpClient();
    console.log("✅ MCP client initialized successfully");
  } catch (err) {
    console.error("❌ Failed to initialize MCP client:", err);
  }
})();

app.post("/chat", async (req, res) => {
  try {
    const msg = req.body.message;
    if (!mcpClient) {
      return res.status(500).json({ error: "MCP client not initialized" });
    }

    // Example call — adjust tool name and parameters as needed
    const result = await mcpClient.callTool("get_insights", { campaign_id: "1234" });
    res.json(result);
  } catch (error) {
    console.error("❌ Error in /chat route:", error);
    res.status(500).json({ error: error.message });
  }
});

app.listen(4000, () => console.log("🚀 Server running on http://localhost:4000"));
